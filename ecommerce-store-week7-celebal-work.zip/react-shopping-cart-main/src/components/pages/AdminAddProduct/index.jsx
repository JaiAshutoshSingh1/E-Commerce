import { AdminProduct } from 'components/common';

const AdminAddProduct = () => {
  return (
    <>
      <AdminProduct />
    </>
  );
};

export default AdminAddProduct;
